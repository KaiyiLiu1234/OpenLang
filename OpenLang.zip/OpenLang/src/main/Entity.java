package main;

public abstract class Entity {

    protected static Main main;

    static void init(Main m) {
        main = m;
    }

}
